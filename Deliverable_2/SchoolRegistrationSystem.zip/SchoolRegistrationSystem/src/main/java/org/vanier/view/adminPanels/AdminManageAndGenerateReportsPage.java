package org.vanier.view.adminPanels;

import javax.swing.*;

public class AdminManageAndGenerateReportsPage {
    private JButton returnToPreviousPageButton;
    private JTextField studentIdTextField;
    private JButton manageButton;
    private JButton generateReportButton;
}
